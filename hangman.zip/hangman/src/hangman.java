import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Collections;
import java.util.*;


/*
 * This is a hangman game. The computer generates the word from a pre-set list of words, according
 * to the user's choice of difficulty. The user then has 6 bad guesses to guess the word, by
 * entering a letter for each guess. If the user wins, it is logged as apoint and user has the choice
 * to continue the game.
 * If user chooses to quit at ny point, the system shows the total number
 * of games won and played.
 * The game ends when the user wins or runs out of bad guesses.
 */

/**
 *
 * @author Esha Shah
 */
public class hangman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        //declaring and initializing various variables required for the game
        int level;
        String play = "";
        int won_stat=0;
        int total_stat=0;
        ArrayList<Character> guesses = new ArrayList<>();
        final int maxTries = 6;
        int badGuesses = 0;
        boolean gameWon = true;
        ArrayList<String> words = new ArrayList<>();
        String level1 = "easy.txt";
        String level2 = "medium.txt";
        String level3 = "hard.txt";

        Scanner inFile = null;

        //welcome message
        System.out.println("****************");
        System.out.print("* HANGMAN GAME *\n*   WELCOME!   *");
        System.out.println("\n****************");
        System.out.println("\nRules: Choose a difficulty level from the options shown.\n"
                + "Enter one letter at a time to guess the hidden word.\n"
                + "If at any time you enter multiple letters, system will only consider the first letter.\n"
                + "If you have input numbers or special characters, system will consider it a bad guess.\n"
                + "Enjoy!");

        while(true){ //this is the loop for continuing the session when the game has ended

        System.out.print("\nEnter difficulty level (easy: 1, medium: 2, hard: 3, to quit: -1): ");

        //according to user input, the word is read from the corresponding file
        //if the file is not found and throws an exception, print error message and return
        if(in.hasNextInt()){
            level=in.nextInt();
        if(level==1){
        try{
            inFile = new Scanner (new File ("level1.txt"));
        }

        catch(FileNotFoundException e){
            System.out.println("The file cannot be found.");
           return;
                }
        System.out.println("\nLevel : Easy");
        }
        if(level==2){
        try{
            inFile = new Scanner (new File ("level2.txt"));
        }

        catch(FileNotFoundException e){
            System.out.println("The file cannot be found.");
            return;
                }
        System.out.println("\nLevel : Medium");
        }
        if(level==3){
        try{
            inFile = new Scanner (new File ("level3.txt"));
        }

        catch(FileNotFoundException e){
            System.out.println("The file cannot be found.");
            return;
                }
        System.out.println("\nLevel : Hard");
        }
        if(level==-1){
            System.out.println("Your session score: " + won_stat + "/" + total_stat);
            System.out.println("Thank you for playing.");

            break;
      }}
        //if user has not entered correctly, program ends
        else{
            System.out.println("You have not entered correctly. The program will now close.");
            System.exit(0);
        }
        //start incrementing the counter every time the user chooses to play a level
        total_stat++;


        //for the length of the input file, keep adding the words to an array list
        while(inFile.hasNextLine()){
            String word = inFile.nextLine();
            words.add(word);
        }
           //computer randomly generates an index, and uses it to choose a word from the list
           Random randIndex = new Random();
           int index = randIndex.nextInt(words.size());
           String secretWord = words.get(index);
           secretWord = secretWord.toUpperCase();

           //then according to the secret word, the computer creates the corresponding
           // dashes for the hidden word
           char[] secretDashes = new char[secretWord.length()];
           ArrayList<Character> secretDash = new ArrayList<>();
           int secretLength = secretWord.length();
           for (int i = 0; i < secretLength; i++){
               secretDashes[i] =  '_';
               secretDash.add(secretDashes[i]);

            }

           //the game continues running, while the game is not won or maximum
           //number of tries is not reached
           while(!gameWon || badGuesses<maxTries){
               System.out.println("\n\nThe word to guess is: ");
               for (int l =0; l< secretDash.size(); l++){
                   System.out.print(secretDash.get(l)+ " ");
               }
               System.out.println("\n");
               //user input prompted
               System.out.print("Enter a letter (to quit, enter -1): ");
               String ltr = in.next();
               //if user chooses to quit, hangman ends
               if(ltr.equals("-1")){
                   System.out.println("Your session score: " + won_stat + "/" + total_stat);
                   System.out.println("Thank you for playing.");
                   System.exit(0);
               }
               //ensuring the input is case insensitive
               char letter = ltr.charAt(0);
               letter = Character.toUpperCase(letter);

              //add the guessed letters to an array list, which is then sorted
              guesses.add(letter);
              Collections.sort(guesses);

              //if the letter is present in the word, call the replace letter method
              if(secretWord.indexOf(letter)>-1){
              replaceLetter(secretWord, secretDash, letter);
             //if the game is won, increment the user's win score and exit the loop
              if( gameWon(secretDash)==true){
                 won_stat++;
                 break;
             }
              }
              //if letter not in the word, increment bad guesses counter each time by 1
              else{
                  System.out.println("You guessed incorrectly.");
                  badGuesses++;
              }

             //display the letters guessed by the user in alphabetical order
              System.out.print("Letters you have guessed so far: ");
              for (int l =0 ; l < guesses.size(); l++){
                  System.out.print(guesses.get(l)+ " ");
              }
              System.out.println("");
              //display how many time bad guesses and thus user can see how many
              //bad guess tries left
              System.out.println("Number of bad guesses: " + badGuesses + "/" + maxTries);

           }
                guesses.clear();

               //when loop is exited, check why. If because maximum number of
               //tries exceeded, then user has lost the game and display the word
               if(badGuesses>=maxTries){
               System.out.println("\nYou have lost! The word was: " + secretWord);
               badGuesses = 0;}

               //if loop exited because game has been won, print congratulatory message
               else if (gameWon(secretDash)){
                   System.out.println("*~*CONGRATS!*~*");
                   System.out.println("You have guessed correctly!\n"
                           + "The word was - " + secretWord);
               }
               badGuesses =0;
                //ask user if they want to play again
               System.out.println("\nPlay again? (No: -1, Yes: Any other key.)");

               //if not, exit the hangman game
               play = in.next();
               if(play.equals("-1")){
                   System.out.println("Your session score: " + won_stat + "/" + total_stat);
                   System.out.println("Thanks for playing.");
                   System.exit(0);
               }

        }
     inFile.close();
    }

     /*
    This method replaces the letter in the hidden word if the letter input by
    the user matches with the corresponding letters in the word. For every
    letter at the index which matches with the user input letter, the dash in the
    hidden word is replaced by the letter.
    */
    public static void replaceLetter(String secretWord, ArrayList<Character> secretDashes, char letter){

        for(int i = 0; i < secretWord.length(); i++){
            if(secretWord.charAt(i)==letter){
                secretDashes.set(i, letter);
            }
        }
         System.out.println("\nGood guess!");
    }
    /*
    This method checks to see whether the game has been won or not. An integer
    checks to see whether there are any dashes left in the hidden word.
    If the word has been guessed, this means there are no dashes left and thus
    the counter is 0 and the game has been won and the method returns true.
    To ensure the game is being checked each time the letter is entered,
    the counter is reset.
    */
    public static boolean gameWon (ArrayList<Character> secretDash){

        boolean won = false;
        int present =0;

        for (int l=0; l < secretDash.size(); l++){
            if(secretDash.get(l)=='_'){
                present = present +1;
            }
        }
        if(present==0){
            won = true;
        }
        present = 0;
        return won;

    }
}














